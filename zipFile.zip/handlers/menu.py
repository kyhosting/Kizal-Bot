from pyrogram import Client, filters
from pyrogram.types import Message

from config import is_owner, VIP_BENEFITS, VVIP_BENEFITS, VIP_PRICES, VVIP_PRICES
from core.error_handler import handle_errors
from utils.keyboards import get_menu_keyboard, get_main_keyboard
from utils.messages import Messages


@handle_errors
async def show_menu(client: Client, message: Message):
    user_id = message.from_user.id
    keyboard = get_menu_keyboard(user_id)
    text = Messages.get_menu_message()

    await message.reply_text(
        text,
        reply_markup=keyboard
    )


@handle_errors
async def show_status(client: Client, message: Message):
    from core.database import db
    from handlers.start import format_remaining_time, get_user_display_name

    user = message.from_user
    user_id = user.id

    db_user = await db.get_user(user_id)

    if is_owner(user_id):
        role = "OWNER"
        limit_remaining = "∞"
        expired_at = "—"
    elif db_user:
        role = db_user.get("role", "reguler").upper()
        daily_limit = db_user.get("daily_limit", 10)
        daily_used = db_user.get("daily_used", 0)
        limit_remaining = max(0, daily_limit - daily_used)
        expired_at = format_remaining_time(db_user.get("expired_at"))
    else:
        role = "REGULER"
        limit_remaining = 10
        expired_at = "—"

    total_ops = db_user.get("operation_count", 0) if db_user else 0

    status_text = f"""```
📊 STATUS AKUN
───────────────────────────────────────
• NAMA          : {get_user_display_name(user)}
• ID            : {user_id}
• ROLE          : {role}
• MASA AKTIF    : {expired_at}
• LIMIT HARIAN  : {limit_remaining}
• TOTAL OPERASI : {total_ops}
───────────────────────────────────────
```"""

    await message.reply_text(status_text)


@handle_errors
async def show_vip_info(client: Client, message: Message):
    user_id = message.from_user.id
    
    benefits_list = "\n".join([f"• {b}" for b in VIP_BENEFITS])
    
    text = f"""```
⭐ VIP MEMBERSHIP
───────────────────────────────────────

📌 Keuntungan VIP:
{benefits_list}

───────────────────────────────────────
💰 HARGA PAKET VIP
───────────────────────────────────────
• 1 Hari  : Rp {VIP_PRICES['1_day']:,}
• 7 Hari  : Rp {VIP_PRICES['7_days']:,}
• 30 Hari : Rp {VIP_PRICES['30_days']:,}

───────────────────────────────────────
📞 Hubungi @KIFZLDEV untuk upgrade
───────────────────────────────────────
```"""

    await message.reply_text(text, reply_markup=get_main_keyboard(user_id))


@handle_errors
async def show_vvip_info(client: Client, message: Message):
    user_id = message.from_user.id
    
    benefits_list = "\n".join([f"• {b}" for b in VVIP_BENEFITS])
    
    text = f"""```
💎 VVIP MEMBERSHIP
───────────────────────────────────────

📌 Keuntungan VVIP:
{benefits_list}

───────────────────────────────────────
💰 HARGA PAKET VVIP
───────────────────────────────────────
• 1 Hari  : Rp {VVIP_PRICES['1_day']:,}
• 7 Hari  : Rp {VVIP_PRICES['7_days']:,}
• 30 Hari : Rp {VVIP_PRICES['30_days']:,}

───────────────────────────────────────
📞 Hubungi @KIFZLDEV untuk upgrade
───────────────────────────────────────
```"""

    await message.reply_text(text, reply_markup=get_main_keyboard(user_id))


@handle_errors
async def show_profile(client: Client, message: Message):
    from core.database import db
    from handlers.start import format_remaining_time, get_user_display_name
    
    user = message.from_user
    user_id = user.id
    
    db_user = await db.get_user(user_id)
    
    if is_owner(user_id):
        role = "OWNER"
        limit_remaining = "∞"
        expired_at = "Unlimited"
        daily_limit = "∞"
        status = "Active"
    elif db_user:
        role = db_user.get("role", "reguler").upper()
        daily_limit = db_user.get("daily_limit", 10)
        daily_used = db_user.get("daily_used", 0)
        limit_remaining = max(0, daily_limit - daily_used)
        expired_at = format_remaining_time(db_user.get("expired_at"))
        status = db_user.get("status", "active").title()
    else:
        role = "REGULER"
        daily_limit = 10
        limit_remaining = 10
        expired_at = "—"
        status = "Active"
    
    total_ops = db_user.get("operation_count", 0) if db_user else 0
    joined_at = db_user.get("joined_at", "—") if db_user else "—"
    
    text = f"""```
👤 PROFIL PENGGUNA
───────────────────────────────────────

📋 INFORMASI AKUN
───────────────────────────────────────
• Nama      : {get_user_display_name(user)}
• Username  : @{user.username or '—'}
• ID        : {user_id}
• Status    : {status}

───────────────────────────────────────
⭐ MEMBERSHIP
───────────────────────────────────────
• Role         : {role}
• Masa Aktif   : {expired_at}
• Limit Harian : {daily_limit}
• Sisa Limit   : {limit_remaining}

───────────────────────────────────────
📊 STATISTIK
───────────────────────────────────────
• Total Operasi : {total_ops}
• Bergabung     : {joined_at}

───────────────────────────────────────
```"""

    await message.reply_text(text, reply_markup=get_main_keyboard(user_id))


@handle_errors
async def show_monitoring_bot(client: Client, message: Message):
    user_id = message.from_user.id
    
    if not is_owner(user_id):
        await message.reply_text("```\n❌ Akses ditolak! Hanya owner yang bisa mengakses.\n```")
        return
    
    from core.monitoring import BotMonitor
    
    monitor = BotMonitor()
    metrics = await monitor.get_system_metrics()
    bot_stats = await monitor.get_bot_statistics()
    
    text = f"""```
📊 MONITORING BOT
───────────────────────────────────────

🖥️ SYSTEM RESOURCES
───────────────────────────────────────
• CPU Usage    : {metrics['cpu_percent']}%
• Memory Used  : {metrics['memory_used_mb']:.1f} MB
• Memory Total : {metrics['memory_total_mb']:.1f} MB
• Memory %     : {metrics['memory_percent']:.1f}%
• Disk Used    : {metrics['disk_used_gb']:.1f} GB
• Disk Total   : {metrics['disk_total_gb']:.1f} GB
• Disk %       : {metrics['disk_percent']:.1f}%

───────────────────────────────────────
📈 BOT STATISTICS
───────────────────────────────────────
• Total Users    : {bot_stats['total_users']}
• VIP Members    : {bot_stats['vip_count']}
• VVIP Members   : {bot_stats['vvip_count']}
• Total Operasi  : {bot_stats['total_operations']}
• Active Today   : {bot_stats.get('active_today', 0)}

───────────────────────────────────────
⏰ UPTIME
───────────────────────────────────────
• Started: {metrics.get('uptime', 'N/A')}

───────────────────────────────────────
```"""

    await message.reply_text(text, reply_markup=get_main_keyboard(user_id))


@handle_errors
async def show_maintenance(client: Client, message: Message):
    user_id = message.from_user.id
    
    if not is_owner(user_id):
        await message.reply_text("```\n❌ Akses ditolak! Hanya owner yang bisa mengakses.\n```")
        return
    
    from utils.keyboards import get_maintenance_keyboard
    
    text = """```
🔧 MAINTENANCE MODE
───────────────────────────────────────

Pilih operasi maintenance:

🧹 Clear Cache     - Bersihkan file temp
🔄 Reset Sessions  - Reset semua session
📊 DB Optimize     - Optimasi database
🗑️ Clean Logs      - Bersihkan log lama
🔃 Restart Tasks   - Restart background tasks

───────────────────────────────────────
```"""

    await message.reply_text(text, reply_markup=get_maintenance_keyboard())


@handle_errors
async def show_group_management(client: Client, message: Message):
    user_id = message.from_user.id
    
    if not is_owner(user_id):
        await message.reply_text("```\n❌ Akses ditolak! Hanya owner yang bisa mengakses.\n```")
        return
    
    text = """```
👥 MANAJEMEN GRUP
───────────────────────────────────────

Fitur manajemen grup:

📋 List Groups   - Lihat semua grup
➕ Add Group     - Tambah grup baru
➖ Remove Group  - Hapus grup
📊 Group Stats   - Statistik grup
🔔 Broadcast     - Kirim pesan ke semua grup

───────────────────────────────────────
```"""

    await message.reply_text(text, reply_markup=get_main_keyboard(user_id))


@handle_errors
async def show_group_settings(client: Client, message: Message):
    user_id = message.from_user.id
    
    if not is_owner(user_id):
        await message.reply_text("```\n❌ Akses ditolak! Hanya owner yang bisa mengakses.\n```")
        return
    
    text = """```
⚙️ PENGATURAN GRUP
───────────────────────────────────────

Pengaturan grup tersedia:

🔐 Required Groups - Atur grup wajib
📢 Welcome Message - Pesan selamat datang
🛡️ Anti-Spam      - Pengaturan anti-spam
👮 Moderation     - Pengaturan moderasi

───────────────────────────────────────
```"""

    await message.reply_text(text, reply_markup=get_main_keyboard(user_id))


@handle_errors
async def show_bot_system(client: Client, message: Message):
    user_id = message.from_user.id
    
    if not is_owner(user_id):
        await message.reply_text("```\n❌ Akses ditolak! Hanya owner yang bisa mengakses.\n```")
        return
    
    from utils.keyboards import get_bot_system_keyboard
    
    text = """```
🤖 SISTEM BOT
───────────────────────────────────────

Pengaturan sistem bot:

🔑 Bot Tokens    - Kelola token bot
📡 Webhooks      - Pengaturan webhook
🔄 Auto Restart  - Auto restart config
📝 Logging       - Pengaturan log
🔐 Security      - Pengaturan keamanan
🚀 Performance   - Optimasi performa

───────────────────────────────────────
```"""

    await message.reply_text(text, reply_markup=get_bot_system_keyboard())


@handle_errors
async def handle_clear_cache(client: Client, message: Message):
    user_id = message.from_user.id
    
    if not is_owner(user_id):
        return
    
    import os
    import glob
    
    temp_files = glob.glob("tmp/*") + glob.glob("temp_*")
    count = 0
    
    for filepath in temp_files:
        try:
            os.remove(filepath)
            count += 1
        except:
            pass
    
    await message.reply_text(
        f"```\n✅ Cache dibersihkan!\n\n🗑️ {count} file dihapus\n```",
        reply_markup=get_main_keyboard(user_id)
    )


@handle_errors
async def handle_reset_sessions(client: Client, message: Message):
    user_id = message.from_user.id
    
    if not is_owner(user_id):
        return
    
    from core.database import db
    
    conn = await db.connect()
    await conn.execute("DELETE FROM user_sessions")
    await conn.commit()
    
    await message.reply_text(
        "```\n✅ Semua session berhasil direset!\n```",
        reply_markup=get_main_keyboard(user_id)
    )


@handle_errors
async def handle_db_optimize(client: Client, message: Message):
    user_id = message.from_user.id
    
    if not is_owner(user_id):
        return
    
    from core.database import db
    
    conn = await db.connect()
    await conn.execute("VACUUM")
    await conn.execute("ANALYZE")
    
    await message.reply_text(
        "```\n✅ Database berhasil dioptimasi!\n\nVACUUM dan ANALYZE completed.\n```",
        reply_markup=get_main_keyboard(user_id)
    )


@handle_errors
async def handle_clean_logs(client: Client, message: Message):
    user_id = message.from_user.id
    
    if not is_owner(user_id):
        return
    
    from core.database import db
    from datetime import datetime, timedelta
    
    conn = await db.connect()
    cutoff = datetime.now() - timedelta(days=7)
    result = await conn.execute(
        "DELETE FROM logs WHERE timestamp < ?",
        (cutoff,)
    )
    await conn.commit()
    
    await message.reply_text(
        f"```\n✅ Log lama berhasil dibersihkan!\n\n🗑️ Log lebih dari 7 hari dihapus\n```",
        reply_markup=get_main_keyboard(user_id)
    )


def register_menu_handlers(app: Client):
    app.on_message(filters.regex("^🜲 Menu Utama 🜲$") & filters.private)(show_menu)
    app.on_message(filters.regex("^🜲 STATUS 🜲$") & filters.private)(show_status)
    app.on_message(filters.regex("^🜲 VIP 🜲$") & filters.private)(show_vip_info)
    app.on_message(filters.regex("^🜲 VVIP 🜲$") & filters.private)(show_vvip_info)
    app.on_message(filters.regex("^🜲 Profil 🜲$") & filters.private)(show_profile)
    app.on_message(filters.regex("^🜲 Monitoring Bot 🜲$") & filters.private)(show_monitoring_bot)
    app.on_message(filters.regex("^🜲 Maintenance 🜲$") & filters.private)(show_maintenance)
    app.on_message(filters.regex("^🜲 Manajemen Grup 🜲$") & filters.private)(show_group_management)
    app.on_message(filters.regex("^🜲 Pengaturan Grup 🜲$") & filters.private)(show_group_settings)
    app.on_message(filters.regex("^🜲 Sistem Bot 🜲$") & filters.private)(show_bot_system)
    app.on_message(filters.regex("^🜲 Clear Cache 🜲$") & filters.private)(handle_clear_cache)
    app.on_message(filters.regex("^🜲 Reset Sessions 🜲$") & filters.private)(handle_reset_sessions)
    app.on_message(filters.regex("^🜲 DB Optimize 🜲$") & filters.private)(handle_db_optimize)
    app.on_message(filters.regex("^🜲 Clean Logs 🜲$") & filters.private)(handle_clean_logs)
