import os
import asyncio
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
from pyrogram import Client

from core.security import Security

logger = logging.getLogger("bot")


class BotInstance:
    def __init__(self, bot_id: int, name: str, token: str):
        self.bot_id = bot_id
        self.name = name
        self.token = token
        self.client: Optional[Client] = None
        self.status = "stopped"
        self.started_at: Optional[datetime] = None
        self.user_count = 0
        self.message_count = 0
        self.error_count = 0
        self.last_activity: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "bot_id": self.bot_id,
            "name": self.name,
            "status": self.status,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "user_count": self.user_count,
            "message_count": self.message_count,
            "error_count": self.error_count,
            "last_activity": self.last_activity.isoformat() if self.last_activity else None
        }


class BotManager:
    _instance = None
    _bots: Dict[int, BotInstance] = {}
    _security: Optional[Security] = None
    _db = None
    _encryption_enabled = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._bots = {}
            encryption_key = os.getenv("ENCRYPTION_KEY", "")
            if encryption_key:
                cls._security = Security(encryption_key)
                cls._encryption_enabled = True
                logger.info("Bot token encryption enabled")
            else:
                cls._security = Security()
                cls._encryption_enabled = False
                logger.warning("ENCRYPTION_KEY not set - using auto-generated key. Bot tokens will not persist across restarts.")
        return cls._instance
    
    async def initialize(self):
        from core.database import db
        self._db = db
        await self._ensure_tables()
        await self._load_bots_from_db()
        logger.info("BotManager initialized")
    
    async def _ensure_tables(self):
        conn = await self._db.connect()
        await conn.executescript("""
            CREATE TABLE IF NOT EXISTS bot_tokens (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                token_encrypted TEXT NOT NULL,
                api_id INTEGER,
                api_hash TEXT,
                status TEXT DEFAULT 'active' CHECK (status IN ('active', 'stopped', 'error')),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_active TIMESTAMP,
                user_count INTEGER DEFAULT 0,
                message_count INTEGER DEFAULT 0,
                error_count INTEGER DEFAULT 0,
                created_by INTEGER
            );
            
            CREATE TABLE IF NOT EXISTS bot_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER,
                metric_type TEXT,
                metric_value REAL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (bot_id) REFERENCES bot_tokens(id)
            );
        """)
        await conn.commit()
    
    async def _load_bots_from_db(self):
        conn = await self._db.connect()
        cursor = await conn.execute("SELECT * FROM bot_tokens WHERE status != 'deleted'")
        rows = await cursor.fetchall()
        
        for row in rows:
            bot_data = dict(row)
            try:
                token = self._security.decrypt(bot_data['token_encrypted'])
                if token:
                    instance = BotInstance(
                        bot_id=bot_data['id'],
                        name=bot_data['name'],
                        token=token
                    )
                    instance.status = bot_data['status']
                    instance.user_count = bot_data.get('user_count', 0)
                    instance.message_count = bot_data.get('message_count', 0)
                    instance.error_count = bot_data.get('error_count', 0)
                    self._bots[bot_data['id']] = instance
            except Exception as e:
                logger.error(f"Failed to load bot {bot_data['name']}: {e}")
    
    async def add_bot(self, name: str, token: str, api_id: int = None, api_hash: str = None, created_by: int = None) -> Dict[str, Any]:
        if not self._validate_token_format(token):
            return {"success": False, "message": "Token format tidak valid"}
        
        if not self._encryption_enabled:
            return {
                "success": False, 
                "message": "ENCRYPTION_KEY belum diatur! Set environment variable ENCRYPTION_KEY untuk menggunakan fitur multi-bot."
            }
        
        encrypted_token = self._security.encrypt(token)
        
        try:
            conn = await self._db.connect()
            cursor = await conn.execute("""
                INSERT INTO bot_tokens (name, token_encrypted, api_id, api_hash, created_by)
                VALUES (?, ?, ?, ?, ?)
            """, (name, encrypted_token, api_id, api_hash, created_by))
            await conn.commit()
            
            bot_id = cursor.lastrowid
            
            instance = BotInstance(bot_id=bot_id, name=name, token=token)
            self._bots[bot_id] = instance
            
            logger.info(f"Bot added: {name} (ID: {bot_id})")
            
            return {
                "success": True,
                "bot_id": bot_id,
                "message": f"Bot '{name}' berhasil ditambahkan"
            }
            
        except Exception as e:
            logger.error(f"Failed to add bot: {e}")
            return {"success": False, "message": f"Gagal menambahkan bot: {str(e)}"}
    
    def _validate_token_format(self, token: str) -> bool:
        if not token:
            return False
        parts = token.split(':')
        if len(parts) != 2:
            return False
        try:
            int(parts[0])
            return len(parts[1]) >= 30
        except ValueError:
            return False
    
    async def start_bot(self, bot_id: int) -> Dict[str, Any]:
        if bot_id not in self._bots:
            return {"success": False, "message": "Bot tidak ditemukan"}
        
        instance = self._bots[bot_id]
        
        if instance.status == "running":
            return {"success": False, "message": "Bot sudah berjalan"}
        
        try:
            instance.status = "running"
            instance.started_at = datetime.now()
            
            await self._update_bot_status(bot_id, "active")
            
            logger.info(f"Bot started: {instance.name} (ID: {bot_id})")
            
            return {
                "success": True,
                "message": f"Bot '{instance.name}' berhasil dijalankan"
            }
            
        except Exception as e:
            instance.status = "error"
            instance.error_count += 1
            logger.error(f"Failed to start bot {bot_id}: {e}")
            return {"success": False, "message": f"Gagal menjalankan bot: {str(e)}"}
    
    async def stop_bot(self, bot_id: int) -> Dict[str, Any]:
        if bot_id not in self._bots:
            return {"success": False, "message": "Bot tidak ditemukan"}
        
        instance = self._bots[bot_id]
        
        try:
            if instance.client:
                await instance.client.stop()
                instance.client = None
            
            instance.status = "stopped"
            
            await self._update_bot_status(bot_id, "stopped")
            
            logger.info(f"Bot stopped: {instance.name} (ID: {bot_id})")
            
            return {
                "success": True,
                "message": f"Bot '{instance.name}' berhasil dihentikan"
            }
            
        except Exception as e:
            logger.error(f"Failed to stop bot {bot_id}: {e}")
            return {"success": False, "message": f"Gagal menghentikan bot: {str(e)}"}
    
    async def delete_bot(self, bot_id: int) -> Dict[str, Any]:
        if bot_id not in self._bots:
            return {"success": False, "message": "Bot tidak ditemukan"}
        
        instance = self._bots[bot_id]
        
        await self.stop_bot(bot_id)
        
        try:
            conn = await self._db.connect()
            await conn.execute(
                "UPDATE bot_tokens SET status = 'deleted' WHERE id = ?",
                (bot_id,)
            )
            await conn.commit()
            
            del self._bots[bot_id]
            
            logger.info(f"Bot deleted: {instance.name} (ID: {bot_id})")
            
            return {
                "success": True,
                "message": f"Bot '{instance.name}' berhasil dihapus"
            }
            
        except Exception as e:
            logger.error(f"Failed to delete bot {bot_id}: {e}")
            return {"success": False, "message": f"Gagal menghapus bot: {str(e)}"}
    
    async def _update_bot_status(self, bot_id: int, status: str):
        conn = await self._db.connect()
        await conn.execute(
            "UPDATE bot_tokens SET status = ?, last_active = CURRENT_TIMESTAMP WHERE id = ?",
            (status, bot_id)
        )
        await conn.commit()
    
    async def get_all_bots(self) -> List[Dict[str, Any]]:
        return [instance.to_dict() for instance in self._bots.values()]
    
    async def get_bot(self, bot_id: int) -> Optional[Dict[str, Any]]:
        if bot_id in self._bots:
            return self._bots[bot_id].to_dict()
        return None
    
    async def get_bot_stats(self, bot_id: int) -> Dict[str, Any]:
        if bot_id not in self._bots:
            return {"success": False, "message": "Bot tidak ditemukan"}
        
        instance = self._bots[bot_id]
        
        uptime = None
        if instance.started_at and instance.status == "running":
            uptime = (datetime.now() - instance.started_at).total_seconds()
        
        return {
            "success": True,
            "stats": {
                "name": instance.name,
                "status": instance.status,
                "uptime_seconds": uptime,
                "user_count": instance.user_count,
                "message_count": instance.message_count,
                "error_count": instance.error_count,
                "started_at": instance.started_at.isoformat() if instance.started_at else None
            }
        }
    
    async def record_bot_activity(self, bot_id: int, activity_type: str = "message"):
        if bot_id in self._bots:
            instance = self._bots[bot_id]
            instance.last_activity = datetime.now()
            
            if activity_type == "message":
                instance.message_count += 1
            elif activity_type == "user":
                instance.user_count += 1
            elif activity_type == "error":
                instance.error_count += 1
    
    async def get_summary(self) -> Dict[str, Any]:
        total = len(self._bots)
        running = sum(1 for b in self._bots.values() if b.status == "running")
        stopped = sum(1 for b in self._bots.values() if b.status == "stopped")
        error = sum(1 for b in self._bots.values() if b.status == "error")
        
        total_users = sum(b.user_count for b in self._bots.values())
        total_messages = sum(b.message_count for b in self._bots.values())
        
        return {
            "total_bots": total,
            "running": running,
            "stopped": stopped,
            "error": error,
            "total_users": total_users,
            "total_messages": total_messages
        }


bot_manager = BotManager()
